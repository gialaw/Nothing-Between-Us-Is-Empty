#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <string>
#include <vector>

struct Vec2 {
    double x{}, y{};
    Vec2 operator+(const Vec2& o) const { return {x + o.x, y + o.y}; }
    Vec2 operator-(const Vec2& o) const { return {x - o.x, y - o.y}; }
    Vec2 operator*(double s) const { return {x * s, y * s}; }
};

static double norm(const Vec2& v) { return std::sqrt(v.x*v.x + v.y*v.y); }

struct Spacecraft {
    int id;
    Vec2 position;
    Vec2 velocity;
    double fuel_cost = 0.0;
    bool maneuvered = false;
};

struct Scenario {
    std::vector<Spacecraft> craft;
    double dt = 1.0;
    int steps = 300;
    double collision_radius = 1.0; // NORMALIZED RESEARCH UNIT, not a flight value.
};

struct Metrics {
    bool collision = false;
    double minimum_separation = std::numeric_limits<double>::infinity();
    double total_maneuver_cost = 0.0;
    int maneuvers = 0;
};

/*
 * IMPORTANT SCIENTIFIC BOUNDARY
 * -----------------------------
 * This first prototype deliberately does NOT claim to be a high-fidelity orbital
 * propagator. The cited CAM review describes uncertainty propagation, probability
 * of collision, maneuver optimization, thrust constraints, and other higher-fidelity
 * methods. Those should be added only after their equations/parameters are selected
 * from the supplied sources.
 *
 * The current simulator is a controlled comparative environment:
 * identical initial conditions -> centralized controller vs. distributed controller.
 */

static void propagate(Spacecraft& s, double dt) {
    s.position = s.position + s.velocity * dt;
}

static double pair_distance(const Spacecraft& a, const Spacecraft& b) {
    return norm(a.position - b.position);
}

static Vec2 avoidance_vector(const Spacecraft& a, const Spacecraft& b) {
    Vec2 d = a.position - b.position;
    double n = norm(d);
    if (n < 1e-12) return {1.0, 0.0};
    return d * (1.0 / n);
}

/* Baseline: a single centralized authority selects one craft to maneuver. */
static void centralized_controller(Scenario& s) {
    double min_d = std::numeric_limits<double>::infinity();
    int ai = -1, bi = -1;

    for (int i = 0; i < (int)s.craft.size(); ++i) {
        for (int j = i + 1; j < (int)s.craft.size(); ++j) {
            double d = pair_distance(s.craft[i], s.craft[j]);
            if (d < min_d) {
                min_d = d; ai = i; bi = j;
            }
        }
    }

    if (ai >= 0 && min_d < 5.0) {
        // Deliberately normalized action. Replace with a source-derived CAM model.
        Vec2 dv = avoidance_vector(s.craft[ai], s.craft[bi]) * 0.01;
        s.craft[ai].velocity = s.craft[ai].velocity + dv;
        s.craft[ai].fuel_cost += norm(dv);
        s.craft[ai].maneuvered = true;
    }
}

/*
 * Mycelium-inspired distributed controller
 *
 * SOURCE-GROUNDED BIOLOGICAL ABSTRACTIONS:
 * - mycelium is a branching/interconnected network;
 * - electrical activity has been observed to fluctuate with environmental conditions;
 * - propagating spike trains have been reported;
 * - the source explicitly cautions that these signals are NOT established proof
 *   of cognition or communication.
 *
 * We therefore model only:
 *   local sensing -> signal propagation -> adaptive edge strength -> local action.
 *
 * "Hyperbolic" here means that network proximity is computed with the
 * Poincare-ball distance formula from the supplied hyperbolic graph source.
 * It is NOT a claim that fungi perform hyperbolic computation.
 */

struct Edge {
    int a, b;
    double strength = 1.0;
};

static double poincare_distance(const Vec2& a, const Vec2& b) {
    const double eps = 1e-9;
    double na = std::min(norm(a), 1.0 - eps);
    double nb = std::min(norm(b), 1.0 - eps);

    double numerator = 1.0 + 2.0 * std::pow(norm(a - b), 2);
    double denominator = std::max((1.0 - na*na) * (1.0 - nb*nb), eps);
    double arg = std::max(1.0, numerator / denominator);
    return std::acosh(arg);
}

/* Map local normalized risk features into the Poincare ball. */
static Vec2 hyperbolic_embedding(const Spacecraft& s, double local_risk) {
    // Research representation, not a learned embedding.
    // A future AI model can replace this function.
    double r = std::tanh(0.5 * local_risk);
    double angle = std::atan2(s.velocity.y, s.velocity.x);
    return {r * std::cos(angle), r * std::sin(angle)};
}

static void distributed_mycelial_controller(Scenario& s, std::vector<Edge>& edges) {
    const int n = (int)s.craft.size();

    for (int i = 0; i < n; ++i) {
        double local_risk = 0.0;

        for (int j = 0; j < n; ++j) {
            if (i == j) continue;
            double d = pair_distance(s.craft[i], s.craft[j]);
            if (d < 5.0) {
                local_risk += (5.0 - d) / 5.0;
            }
        }

        if (local_risk <= 0.0) continue;

        Vec2 emb_i = hyperbolic_embedding(s.craft[i], local_risk);

        // Signal propagates locally through the adaptive graph.
        for (auto& e : edges) {
            if (e.a != i && e.b != i) continue;
            int j = (e.a == i) ? e.b : e.a;

            double neighbor_risk = 0.0;
            double d = pair_distance(s.craft[i], s.craft[j]);
            if (d < 5.0) neighbor_risk = (5.0 - d) / 5.0;

            Vec2 emb_j = hyperbolic_embedding(s.craft[j], neighbor_risk);
            double hd = poincare_distance(emb_i, emb_j);

            // Adaptive signal strength: stronger when local risk is high and
            // hyperbolic network distance is small.
            double signal = local_risk / (1.0 + hd);
            e.strength = std::clamp(0.95 * e.strength + 0.05 * signal, 0.0, 1.0);

            // Local action: no central authority chooses the maneuvering craft.
            if (neighbor_risk > 0.0 && e.strength > 0.15) {
                Vec2 away = avoidance_vector(s.craft[i], s.craft[j]);
                double magnitude = 0.01 * e.strength;
                Vec2 dv = away * magnitude;
                s.craft[i].velocity = s.craft[i].velocity + dv;
                s.craft[i].fuel_cost += norm(dv);
                s.craft[i].maneuvered = true;
            }
        }
    }
}

static Metrics run(Scenario scenario, bool distributed) {
    std::vector<Edge> edges;
    for (int i = 0; i < (int)scenario.craft.size(); ++i)
        for (int j = i + 1; j < (int)scenario.craft.size(); ++j)
            edges.push_back({i, j, 1.0});

    Metrics m;

    for (int step = 0; step < scenario.steps; ++step) {
        if (distributed)
            distributed_mycelial_controller(scenario, edges);
        else
            centralized_controller(scenario);

        for (auto& s : scenario.craft) {
            propagate(s, scenario.dt);
            s.maneuvered = false;
        }

        for (int i = 0; i < (int)scenario.craft.size(); ++i) {
            for (int j = i + 1; j < (int)scenario.craft.size(); ++j) {
                double d = pair_distance(scenario.craft[i], scenario.craft[j]);
                m.minimum_separation = std::min(m.minimum_separation, d);
                if (d < scenario.collision_radius) m.collision = true;
            }
        }
    }

    for (const auto& s : scenario.craft) {
        m.total_maneuver_cost += s.fuel_cost;
        if (s.fuel_cost > 0.0) ++m.maneuvers;
    }

    return m;
}

static Scenario make_scenario() {
    Scenario s;
    s.craft = {
        {0, {-10.0,  0.0}, { 0.10,  0.00}},
        {1, { 10.0,  0.2}, {-0.10,  0.00}},
        {2, {  0.0,  8.0}, { 0.00, -0.02}}
    };
    return s;
}

int main() {
    Scenario baseline = make_scenario();

    Metrics centralized = run(baseline, false);
    Metrics mycelial = run(baseline, true);

    std::cout << std::fixed << std::setprecision(6);
    std::cout << "CENTRALIZED\n";
    std::cout << "collision=" << centralized.collision
              << " min_separation=" << centralized.minimum_separation
              << " maneuver_cost=" << centralized.total_maneuver_cost
              << " maneuvering_spacecraft=" << centralized.maneuvers << "\n\n";

    std::cout << "MYCELIUM_HYPERBOLIC\n";
    std::cout << "collision=" << mycelial.collision
              << " min_separation=" << mycelial.minimum_separation
              << " maneuver_cost=" << mycelial.total_maneuver_cost
              << " maneuvering_spacecraft=" << mycelial.maneuvers << "\n";

    std::ofstream out("results.csv");
    out << "architecture,collision,minimum_separation,maneuver_cost,maneuvering_spacecraft\n";
    out << "centralized," << centralized.collision << ","
        << centralized.minimum_separation << ","
        << centralized.total_maneuver_cost << ","
        << centralized.maneuvers << "\n";
    out << "mycelium_hyperbolic," << mycelial.collision << ","
        << mycelial.minimum_separation << ","
        << mycelial.total_maneuver_cost << ","
        << mycelial.maneuvers << "\n";

    return 0;
}
