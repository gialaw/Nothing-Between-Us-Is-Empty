# Mycelial Space Coordination

A research prototype comparing two spacecraft collision-coordination architectures under identical simulated conditions:

1. Centralized decision-making
2. Distributed mycelium-inspired coordination using an adaptive graph and hyperbolic network distance

## Scientific basis

The project does **not** claim that fungi perform hyperbolic computation or that fungal electrical activity has been proven to represent cognition.

The mycelium abstraction is limited to documented observations reported in the supplied literature:

- interconnected/branching mycelial networks
- electrical activity responsive to environmental conditions
- propagating electrical spike trains
- distributed sensing and signal propagation

The supplied *Symbiotic Intelligence: Rethinking AI with Mycelium* paper explicitly states that fungal electrical signals should not be treated as empirical evidence of cognition or communication.

Hyperbolic geometry is independently defined from the supplied hyperbolic graph-embedding literature. The current prototype uses the Poincare-ball distance as a network metric.

## Orbital-model boundary

The current program is a controlled comparative research prototype, not a flight-qualified orbital propagator.

It intentionally uses normalized relative-motion variables. High-fidelity orbital dynamics, covariance propagation, probability-of-collision calculations, thrust constraints, and maneuver optimization should only be added after their equations and parameters are selected from validated aerospace sources.

The supplied CAM review identifies probability of collision, uncertainty propagation, fuel optimality, computational efficiency, reliability, and robustness as important evaluation considerations.

## Research question

Under identical initial conditions, does a distributed mycelium-inspired adaptive network produce different coordination outcomes from a centralized controller?

## Current outputs

`results.csv` records:

- collision occurrence
- minimum separation
- normalized maneuver cost
- number of spacecraft that maneuvered

## Build

```bash
cmake -S . -B build
cmake --build build
./build/mycelial_sim
```

On Windows with Visual Studio:

```powershell
cmake -S . -B build
cmake --build build --config Release
.\build\Release\mycelial_sim.exe
```

## Next scientific modules

- validated orbital propagation
- covariance / uncertainty propagation
- probability-of-collision model
- realistic maneuver constraints
- Monte Carlo experiment runner
- statistically powered comparison
- learned AI policy
- bioelectronic-interface simulation layer
- hardware interface model for organic electrochemical transistor research

## Important

The current "mycelial" controller is an explicit engineering abstraction. It should be presented as a hypothesis to test, not as a literal simulation of fungal intelligence.
