// Nothing Between Us Is Empty
// A hackathon prototype of mycelium-inspired distributed coordination.
// The model is intentionally an analogy: it does not claim to reproduce fungal cognition.

const canvas = document.getElementById('network');
const ctx = canvas.getContext('2d');
const stressSlider = document.getElementById('stress');
const decisionLog = document.getElementById('decisionLog');
const nodes = [
  {id:'SC-01',type:'spacecraft',x:-.52,y:-.12,energy:.92,alive:true},
  {id:'SC-02',type:'spacecraft',x:-.16,y:-.42,energy:.78,alive:true},
  {id:'SC-03',type:'spacecraft',x:.28,y:-.28,energy:.86,alive:true},
  {id:'SC-04',type:'spacecraft',x:.52,y:.18,energy:.68,alive:true},
  {id:'SC-05',type:'spacecraft',x:.14,y:.48,energy:.81,alive:true},
  {id:'AI-01',type:'ai',x:-.38,y:.30,energy:1,alive:true},
  {id:'AI-02',type:'ai',x:.38,y:-.02,energy:1,alive:true},
  {id:'OPS',type:'human',x:0,y:.02,energy:1,alive:true}
];
let edges=[], aiActions=0,humanActions=0,storm=0,last=performance.now(),time=0;
const colors={spacecraft:'#f29acb',ai:'#b8a9ff',human:'#a8e6cf'};

function resize(){const r=canvas.getBoundingClientRect();const d=window.devicePixelRatio||1;canvas.width=r.width*d;canvas.height=r.height*d;ctx.setTransform(d,0,0,d,0,0)}
window.addEventListener('resize',resize);resize();

function hyperbolicDistance(a,b){
  const dx=a.x-b.x,dy=a.y-b.y, eu2=dx*dx+dy*dy;
  const da=Math.min(a.x*a.x+a.y*a.y,.999999), db=Math.min(b.x*b.x+b.y*b.y,.999999);
  const z=1+(2*eu2)/((1-da)*(1-db));
  return Math.acosh(Math.max(1,z));
}

function sigmoid(x){return 1/(1+Math.exp(-x))}
function oectSignal(input,stress){
  // Abstract OECT-like transfer: a low-voltage biological/chemical input changes channel conductance.
  return sigmoid(3.4*(input + .22*stress - .48));
}

function rebuildEdges(){
  const candidates=[];
  for(let i=0;i<nodes.length;i++)for(let j=i+1;j<nodes.length;j++){
    if(!nodes[i].alive||!nodes[j].alive)continue;
    const d=hyperbolicDistance(nodes[i],nodes[j]);
    if(d<1.85)candidates.push({a:i,b:j,d,weight:Math.exp(-d)});
  }
  candidates.sort((x,y)=>y.weight-x.weight);
  edges=[];
  for(const e of candidates){
    const threshold=.20 + .35*parseFloat(stressSlider.value);
    if(e.weight>threshold) edges.push(e);
  }
}

function logDecision(message,kind='info'){
  const row=document.createElement('div');row.textContent=`[${new Date().toLocaleTimeString()}] ${message}`;row.style.color=kind==='human'?'#a8e6cf':kind==='risk'?'#ffadad':'#b8a9bd';decisionLog.prepend(row);
  while(decisionLog.children.length>8)decisionLog.lastChild.remove();
}

function stormEvent(){
  storm=1;
  nodes.filter(n=>n.type==='spacecraft').forEach(n=>{n.energy=Math.max(.12,n.energy-.22-Math.random()*.12)});
  aiActions++; logDecision('Solar storm detected. AI nodes begin local rerouting.');
}
function restore(){
  const dead=nodes.find(n=>!n.alive);
  if(dead){dead.alive=true;dead.energy=.7;logDecision(`${dead.id} restored to network.`);return}
  const low=nodes.filter(n=>n.type==='spacecraft').sort((a,b)=>a.energy-b.energy)[0];
  low.energy=Math.min(1,low.energy+.18);logDecision(`${low.id} receives redistributed network support.`);
}

document.getElementById('stormBtn').onclick=stormEvent;
document.getElementById('restoreBtn').onclick=restore;
document.getElementById('resetBtn').onclick=()=>location.reload();

function update(dt){
  time+=dt;
  const stress=parseFloat(stressSlider.value);
  if(storm>0){storm=Math.max(0,storm-dt*.16);if(storm===0)logDecision('Storm window closed; network returns to adaptive mode.')}
  nodes.forEach(n=>{if(n.type==='spacecraft'&&n.alive){n.energy=Math.max(.05,Math.min(1,n.energy + (.004 - stress*.003 - storm*.006)*dt*60));}});
  // Local reinforcement: links connecting healthier nodes are strengthened, stressed links decay.
  edges.forEach(e=>{const a=nodes[e.a],b=nodes[e.b];e.weight += ((a.energy+b.energy)/2 - stress*.4)*dt*.015;e.weight=Math.max(.08,Math.min(1,e.weight));});
  if(Math.random()<dt*.25){
    const critical=nodes.find(n=>n.type==='spacecraft'&&n.energy<.35);
    if(critical){humanActions++;logDecision(`${critical.id} crossed autonomy threshold. Operator review requested.`,'human');}
  }
  const input=.15 + stress*.7 + storm*.4;
  const out=oectSignal(input,stress);
  document.getElementById('signalIn').textContent=input.toFixed(2);
  document.getElementById('signalOut').textContent=out.toFixed(2);
  rebuildEdges();
  const healthy=nodes.filter(n=>n.alive).reduce((s,n)=>s+n.energy,0)/(nodes.length);
  document.getElementById('health').textContent=Math.round(healthy*100)+'%';
  document.getElementById('paths').textContent=edges.length;
  document.getElementById('aiActions').textContent=aiActions;
  document.getElementById('humanActions').textContent=humanActions;
}

function project(n){
  const w=canvas.clientWidth,h=canvas.clientHeight;
  const scale=Math.min(w,h)*.43;
  return {x:w/2+n.x*scale,y:h/2+n.y*scale};
}
function draw(){
  const w=canvas.clientWidth,h=canvas.clientHeight;ctx.clearRect(0,0,w,h);
  const scale=Math.min(w,h)*.43;
  // Poincare disk boundary
  ctx.beginPath();ctx.arc(w/2,h/2,scale,0,Math.PI*2);ctx.strokeStyle='rgba(242,154,203,.13)';ctx.stroke();
  // Hyperbolic grid rings
  for(let r=.25;r<1;r+=.25){ctx.beginPath();ctx.arc(w/2,h/2,scale*r,0,Math.PI*2);ctx.strokeStyle='rgba(255,255,255,.035)';ctx.stroke()}
  edges.forEach(e=>{const a=project(nodes[e.a]),b=project(nodes[e.b]);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.lineWidth=1+e.weight*2;ctx.strokeStyle=`rgba(242,154,203,${.08+.42*e.weight})`;ctx.stroke();
    const pulse=(Math.sin(time*2.5+e.a+e.b)+1)/2;const x=a.x+(b.x-a.x)*pulse,y=a.y+(b.y-a.y)*pulse;ctx.beginPath();ctx.arc(x,y,2.2,0,Math.PI*2);ctx.fillStyle='rgba(242,154,203,.75)';ctx.fill();});
  nodes.forEach(n=>{const p=project(n),r=n.type==='human'?10:n.type==='ai'?8:7;ctx.beginPath();ctx.arc(p.x,p.y,r+7,0,Math.PI*2);ctx.fillStyle=`rgba(${n.type==='spacecraft'?'242,154,203':n.type==='ai'?'184,169,255':'168,230,207'},.07)`;ctx.fill();ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*2);ctx.fillStyle=n.alive?colors[n.type]:'#555';ctx.fill();ctx.fillStyle='#f7f0fa';ctx.font='11px ui-monospace,monospace';ctx.textAlign='center';ctx.fillText(n.id,p.x,p.y+r+18);});
  requestAnimationFrame(draw);
}
function loop(now){const dt=Math.min(.05,(now-last)/1000);last=now;update(dt);requestAnimationFrame(loop)}
logDecision('Network initialized. Local coordination online.');
rebuildEdges();requestAnimationFrame(loop);requestAnimationFrame(draw);
