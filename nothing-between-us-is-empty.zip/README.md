# Nothing Between Us Is Empty

**Mycelium-inspired distributed intelligence for spacecraft, AI and human operators**

This is a hackathon research prototype. It asks whether principles observed in mycelial and other ecological networks can inspire resilient coordination architectures for space exploration and environmental restoration.

## What the prototype does

The browser simulation models:

- **Spacecraft nodes** that have local state and energy
- **AI nodes** that help reroute information without controlling every node centrally
- **A human operator node** that receives escalations when a spacecraft crosses a risk threshold
- **Adaptive pathways** that strengthen or decay according to local conditions
- **A Poincaré disk / hyperbolic distance model** as a mathematical representation of relational proximity
- **An abstract OECT-inspired signal layer** that demonstrates how an input can be transformed into an amplified electronic response
- **A solar-storm scenario** that stresses spacecraft and triggers adaptive rerouting

The hyperbolic component is a mathematical network model, not a claim that fungi literally perform hyperbolic computation.

## Run locally

No build system is required.

```bash
git clone https://github.com/YOUR-USERNAME/nothing-between-us-is-empty.git
cd nothing-between-us-is-empty
python -m http.server 8000
```

Open `http://localhost:8000`.

You can also deploy the repository directly through GitHub Pages because the prototype is entirely client-side.

## Research foundation

Wild and Wachsmann's 2026 paper, *Symbiotic Intelligence: Rethinking AI with Mycelium*, frames intelligence as an emergent, relational and ecological phenomenon and argues for alternatives to competitive and extractive AI narratives.

Wild, J., & Wachsmann, S. (2026). *Symbiotic Intelligence: Rethinking AI with Mycelium*. Arts, 15(4), 69. https://doi.org/10.3390/arts15040069

Research on fungal electrical signaling describes evidence and open questions around electrical activity in filamentous fungi, while emphasizing that its biological function remains incompletely understood.

Organic electrochemical transistors (OECTs) are established bioelectronic devices capable of interfacing with biological systems and sensing ionic/biochemical signals. This repository treats them as a future hardware pathway rather than claiming that the current software is an OECT.

## Proposed architecture

```text
                 HUMAN OPERATOR
                       ▲
                       │ escalation
                       │
          ┌────────────┴────────────┐
          │       AI NODES          │
          │ local inference/routing │
          └───────┬────────┬───────┘
                  │        │
             adaptive distributed pathways
          ┌───────┴────────┴────────┐
          │       SPACECRAFT        │
          │ local sensing + action  │
          └─────────────────────────┘

        biological signal → bioelectronic interface
                         ↓
                  adaptive network
                         ↓
             space / Earth restoration
```

## Ethical design principles

1. **Human escalation for high-impact decisions.** Autonomy should not automatically imply authority.
2. **Non-extractive biological research.** Biological systems that inspire the architecture should not be treated merely as computational raw material.
3. **Ecological constraints as system requirements.** Energy, material use and environmental effects should be optimization variables, not afterthoughts.
4. **Distributed power.** Avoid architectures in which a single AI or institution becomes the indispensable controller.
5. **Auditability.** Every autonomous intervention should have an interpretable event trail.
6. **Reciprocity.** Restoration systems should measure whether interventions improve ecosystem conditions rather than merely maximizing an operational metric.

## Next steps

- Add a real delay-tolerant networking model for spacecraft
- Compare centralized control against decentralized/mycelial routing
- Add reinforcement learning or graph neural networks for adaptive routing
- Add multi-agent negotiation between spacecraft and AI nodes
- Add environmental sensor data as a second network domain
- Build an actual low-voltage OECT sensor interface as a hardware companion
- Quantify energy consumption, communication overhead, resilience and recovery time
- Test different human-override policies

## Important scientific distinction

The project uses **mycelium as an inspiration and computational metaphor**. Claims about fungal intelligence, electrical signaling, ecological reciprocity, or biological computation should be tested against experimental literature rather than assumed from the metaphor.
